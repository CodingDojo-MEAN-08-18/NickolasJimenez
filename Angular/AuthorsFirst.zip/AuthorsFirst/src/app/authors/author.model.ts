export interface Author {
  id: string;
  name: string;
}
