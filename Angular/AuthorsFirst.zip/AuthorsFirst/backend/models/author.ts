export class Author {
  id: number ;
  first_name: String;
  last_name: String;
}
