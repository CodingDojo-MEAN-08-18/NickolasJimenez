export class Quote {
  content: String;
}
